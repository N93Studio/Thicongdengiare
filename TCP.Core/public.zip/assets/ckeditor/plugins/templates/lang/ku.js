/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'ku', {
	button: 'ڕووکار',
	emptyListMsg: '(هیچ ڕووکارێك دیارینەکراوە)',
	insertOption: 'لە شوێن دانانی ئەم پێکهاتانەی ئێستا',
	options: 'هەڵبژاردەکانی ڕووکار',
	selectPromptMsg: 'ڕووکارێك هەڵبژێره بۆ کردنەوەی له سەرنووسەر:',
	title: 'پێکهاتەی ڕووکار'
} );
